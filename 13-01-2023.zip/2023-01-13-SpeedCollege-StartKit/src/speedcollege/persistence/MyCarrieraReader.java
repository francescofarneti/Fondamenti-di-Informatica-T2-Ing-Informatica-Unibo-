package speedcollege.persistence;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.Reader;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.FormatStyle;
import java.util.Locale;

import speedcollege.model.AttivitaFormativa;
import speedcollege.model.Carriera;
import speedcollege.model.Esame;
import speedcollege.model.Voto;


public class MyCarrieraReader implements CarrieraReader {

	/*
	 * 	27991	ANALISI MATEMATICA T-1 (cfu:9)			12/01/20	RT
		27991	ANALISI MATEMATICA T-1 (cfu:9)			10/02/20	22
		28004	FONDAMENTI DI INFORMATICA T-1 (cfu:12)	13/02/20	24
		29228	GEOMETRIA E ALGEBRA T (cfu:6)			18/01/20	26
		26337	LINGUA INGLESE B-2 (cfu:6)
		27993	ANALISI MATEMATICA T-2 (cfu:6)			10/06/20	RE
		27993	ANALISI MATEMATICA T-2 (cfu:6)			02/07/20	RT
		28006	FONDAMENTI DI INFORMATICA T-2 (cfu:12)
		28011	RETI LOGICHE T (cfu:6)		
		...
	*/

	@Override
	public Carriera leggiCarriera(Reader rdr) throws IOException {
		if(rdr == null) {
			throw new BadFileFormatException ("reader null");
		}
		BufferedReader reader = new BufferedReader (rdr);
		Carriera carriera = new Carriera();
		String riga;
		while((riga = reader.readLine()) != null) {
			if(riga.isBlank()) {
				continue;
			}
			String [] items = riga.split("\\t+");
			String [] attivitaEcfu = items[1].trim().split("\\(cfu:");
			if(!(items[1].toLowerCase().contains("cfu"))) {
				throw new BadFileFormatException ("manca cfu");
			}
			/**
			 * In Java, il carattere "(" viene utilizzato come carattere speciale
			 * per definire una lista di argomenti all'interno di una chiamata di
			 * metodo o di una dichiarazione di metodo. Ciò significa che se si
			 * vuole utilizzare il carattere "(" in una stringa letterale, è necessario
			 * utilizzare il carattere di escape "\" prima di esso per indicare
			 * che si tratta di un carattere normale e non di un carattere speciale.
			 * Ad esempio, se si vuole scrivere una stringa contenente la sottostringa
			 * "hello(world)", è necessario scriverla come "hello\(world\)". Senza
			 * utilizzare il carattere di escape "\" prima della parentesi "(", Java
			 * interpreterebbe la parentesi "(" come un carattere speciale e genererebbe
			 * un errore di sintassi. Utilizzando invece il carattere di escape "\" prima
			 * della parentesi "(", Java interpretarebbe la parentesi "(" come un carattere
			 * normale e non come un carattere speciale all'interno della stringa letterale.
			 * In generale, il carattere di escape "\" viene utilizzato in Java per
			 * indicare che il carattere successivo nella stringa letterale non deve essere
			 * interpretato come carattere speciale, ma come un carattere normale. Ciò è
			 * particolarmente importante quando si utilizzano caratteri speciali come la
			 * parentesi "(",")", le parentesi quadre "[", "]" e le parentesi graffe "{",
			 * che hanno un significato speciale all'interno del linguaggio Java e che devono
			 * essere utilizzati correttamente all'interno del codice sorgente. Quando si
			 * utilizzano questi caratteri all'interno di una stringa letterale, è necessario
			 * utilizzare il carattere di escape "\" solo per quei caratteri che hanno un
			 * significato speciale in Java, come la parentesi "(".
			 */
			String nomeAf = attivitaEcfu[0].trim();
			if(nomeAf.isBlank()) {
				throw new BadFileFormatException ("nome mancante");
			}
			int cfu;
			long id;
			DateTimeFormatter formatter = DateTimeFormatter.ofLocalizedDate(FormatStyle.SHORT).withLocale(Locale.ITALY);
			try {
				id = Long.parseLong(items[0].trim());
				cfu = Integer.parseInt(attivitaEcfu[1].replace(")", "").trim());
			} catch(Exception e) {
				throw new BadFileFormatException ("errore nel parse" + riga + "-"+ attivitaEcfu[1].toLowerCase().replace("cfu:", "").replace(")", "").trim() +"--");
			}
			if(items.length == 4) {
				LocalDate date;
				Voto voto;
				try {
					date = LocalDate.parse(items[2].trim(), formatter);
					voto = Voto.of(items[3].trim());
				} catch (Exception e) {
					throw new BadFileFormatException ("errore nel parse" + riga);
				}
				
				AttivitaFormativa af = new AttivitaFormativa(id,nomeAf,cfu);
				Esame esame = new Esame (af,date,voto);
				carriera.inserisci(esame);
			}
			else {
				continue;
			}
		}
		/**
		for(Esame esame : carriera.getListaEsami()) {
			if(esame.getAf().getNome().toLowerCase().contains("prova finale")) {
				if(carriera.getUltimoEsameDato().isPresent() && !(carriera.getUltimoEsameDato().get().equals(esame))) {
					throw new BadFileFormatException ("prova finale non è ultimo esame");
				}
			}
		}
		*/
		return carriera;
	}

}