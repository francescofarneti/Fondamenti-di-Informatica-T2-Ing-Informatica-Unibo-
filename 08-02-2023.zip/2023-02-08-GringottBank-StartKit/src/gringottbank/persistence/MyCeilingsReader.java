package gringottbank.persistence;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.Reader;
import java.util.ArrayList;
import java.util.List;

import gringottbank.model.Ceiling;
import gringottbank.model.Coin;
import gringottbank.model.CoinAmount;

	 /*
		Harry		20 galeoni
		Hermione	19 galeoni, 20 zellini
		Enrico		200 galeoni
		Ambra		100 galeoni, 20 zellini
		Roberta		100 galeoni, 28 zellini
		Ron			12 galeoni, 10 falci, 6 zellini
	 */

public class MyCeilingsReader implements CeilingsReader {

	@Override
	public List<Ceiling> readCeilings(Reader rdr) throws IOException, BadFileFormatException {
		// DA IMPLEMENTARE
		BufferedReader reader = new BufferedReader(rdr);
		List<Ceiling> lista = new ArrayList<>();
		String riga;
		while((riga = reader.readLine()) != null) {
			String [] items = riga.split("\\t+");
			if(items.length!=2) throw new BadFileFormatException();
			String nome = items[0].trim();
			if(nome.isBlank()) throw new BadFileFormatException();
			String [] soldi = items[1].split(",");
			int galeoni = 0;
			int zellini = 0;
			int falci = 0;
			for(int i = 0; i<soldi.length; i++) {
				if(soldi[i].toLowerCase().contains("galeoni") && soldi[i].trim().contains(" ")) {
					galeoni = parsePositive(soldi[i].toLowerCase().replace("galeoni", "").trim());
				}
				else if(soldi[i].toLowerCase().contains("falci") && soldi[i].trim().contains(" ")) {
					falci = parsePositive(soldi[i].toLowerCase().replace("falci", "").trim());
				}
				else if(soldi[i].toLowerCase().contains("zellini") && soldi[i].trim().contains(" ")) {
					zellini = parsePositive(soldi[i].toLowerCase().replace("zellini", "").trim());
				}
				else {
					throw new BadFileFormatException();
				}
			}
			CoinAmount amount = new CoinAmount();
			amount.plus(Coin.GALLEON, galeoni);
			amount.plus(Coin.SICKLE, falci);
			amount.plus(Coin.KNUT, zellini);
			Ceiling ceiling = new Ceiling(nome,amount);
			lista.add(ceiling);
		}
		return lista;
	}
	
	

	private int parsePositive(String s) throws BadFileFormatException {
		// METODO DI UTILITA' IN REGALO :)
		int importo;
		try {
			importo = Integer.parseInt(s);
		}
		catch(NumberFormatException e) {
			throw new BadFileFormatException("Formato sotto-importo illegale: numero errato\t" + s);
		}
		if (importo<0) throw new BadFileFormatException("Formato sotto-importo illegale: numero negativo\t" + s);
		return importo;
	}
	
}