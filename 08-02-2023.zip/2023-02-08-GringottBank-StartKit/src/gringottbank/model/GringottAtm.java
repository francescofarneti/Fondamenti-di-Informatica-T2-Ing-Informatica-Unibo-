package gringottbank.model;

public class GringottAtm implements Atm {

	public CoinAmount normalize(CoinAmount amount) {
		int galleons = amount.getQuantity(Coin.GALLEON);
		int sickles =  amount.getQuantity(Coin.SICKLE);
		int knuts =    amount.getQuantity(Coin.KNUT);
		while (knuts > Coin.SICKLE.getDivider()) { knuts -=Coin.SICKLE.getDivider(); sickles++; }
		while (sickles > Coin.GALLEON.getDivider()) { sickles -=Coin.GALLEON.getDivider(); galleons++; }
		return new CoinAmount().plus(Coin.GALLEON, galleons).plus(Coin.SICKLE,sickles).plus(Coin.KNUT,knuts);
	} 

	/* 	3) L’importo in monete Gringott deve prevedere il massimo numero di galeoni possibile, 
		   garantendo tuttavia che siano sempre essere erogati almeno 5 falci d’argento. 
		4) Nel caso di importi specificati in Dollari, Euro o Sterline, deve essere usato il 
		   tasso di cambio fisso prestabilito
	   ESEMPI
		20 galeoni --> 19 galeoni + 17 falci
		19 galeoni e 20 zellini --> 18 galeoni + 17 falci + 20 zellini
		500 sterline --> (1 galeone = £ 5.00) 100 galeoni teorici --> 99 galeoni +17 falci
		500 euro     --> (1 galeone = € 5.66) 88 galeoni + 5 falci + 22 zellini (importo effettivo: 499,67 €)
		500 dollari  --> (1 galeone = $ 6.00) 83 galeoni + 5 falci + 19 zellini (importo effettivo: 499,67 €)
	*/

	@Override
	public Amount withdraw(CoinAmount amount) throws ImpossibleWithdrawException {
		// DA IMPLEMENTARE
		int amountInZellini = amount.getValueInKnuts();
		amountInZellini = amountInZellini - 5*29; //tolgo le 5 falci
		int galeoni = (int) Math.floor(amountInZellini * 1.0 /(17*29));
		int resto = amountInZellini % (17*29);
		int falci = (int) Math.floor(resto * 1.0 /29) + 5; //rimetto le 5 falci
		int zellini = (int) (resto % 29);
		
		CoinAmount result = new CoinAmount();
		result.plus(Coin.GALLEON, galeoni);
		result.plus(Coin.SICKLE, falci);
		result.plus(Coin.KNUT, zellini);
		
		return result;
	}

	@Override
	public Amount withdraw(CurrencyAmount amount) throws ImpossibleWithdrawException {
		// DA IMPLEMENTARE
		CoinAmount result;
		if(amount.getCurrency().equals(Currency.EUR)) {
			int amountInZellini = (int) Math.floor(amount.getQuantity()*17*29*1.0/5.66);
			amountInZellini = amountInZellini - 5*29; //tolgo le 5 falci
			int galeoni = (int) Math.floor(amountInZellini * 1.0 /(17*29));
			int resto = amountInZellini % (17*29);
			int falci = (int) Math.floor(resto * 1.0 /29) + 5; //rimetto le 5 falci
			int zellini = (int) (resto % 29);
			
			result = new CoinAmount();
			result.plus(Coin.GALLEON, galeoni);
			result.plus(Coin.SICKLE, falci);
			result.plus(Coin.KNUT, zellini);
		}
		else if(amount.getCurrency().equals(Currency.GBP)) {
			int amountInZellini = (int) Math.floor(amount.getQuantity()*17*29*1.0/5.0);
			amountInZellini = amountInZellini - 5*29; //tolgo le 5 falci
			int galeoni = (int) Math.floor(amountInZellini * 1.0 /(17*29));
			int resto = amountInZellini % (17*29);
			int falci = (int) Math.floor(resto * 1.0 /29) + 5; //rimetto le 5 falci
			int zellini = (int) (resto % 29);
			
			result = new CoinAmount();
			result.plus(Coin.GALLEON, galeoni);
			result.plus(Coin.SICKLE, falci);
			result.plus(Coin.KNUT, zellini);
		}
		else {
			int amountInZellini = (int) Math.floor(amount.getQuantity()*17*29*1.0/6.0);
			amountInZellini = amountInZellini - 5*29; //tolgo le 5 falci
			int galeoni = (int) Math.floor(amountInZellini * 1.0 /(17*29));
			int resto = amountInZellini % (17*29);
			int falci = (int) Math.floor(resto * 1.0 /29) + 5; //rimetto le 5 falci
			int zellini = (int) (resto % 29);
			
			result = new CoinAmount();
			result.plus(Coin.GALLEON, galeoni);
			result.plus(Coin.SICKLE, falci);
			result.plus(Coin.KNUT, zellini);
		}
		return result;
	}
	
}
