package mediaesami.model;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

public class Carriera {	
	private List<Esame> listaEsami;
	private Comparator<Esame> cmp;
	
	public Carriera() {
		// DA FARE
		this.listaEsami = new ArrayList<>();
		cmp = Comparator.comparing(Esame::getDate).thenComparing((Esame e) -> e.getAf().getId());
		/**
		 * questo giro non mi basta creare una funzione che richiami un metodo della mia classe, devo
		 * generare una funzione che richiami un metodo da una classe di supporto ovvero attivitaFormativa,
		 * quindi uso la lambda nel formato non per richiamare un metodo interno ma che rimane più generale
		 * e che mi permette di andare a prenderlo anche fuori
		 */
	}
	
	public List<Esame> getListaEsami() {
		return listaEsami;
	}

	public List<Esame> getTentativiPrecedenti(Esame esame){
		// DA FARE
		List<Esame> tentativi = new ArrayList<>();
		for(Esame test : this.listaEsami) {
			if(test.getAf().equals(esame.getAf()) && !(test.getVoto().superato())) {
				tentativi.add(esame);
			}
		}
		tentativi.sort(cmp);
		return tentativi;
	}
		
	public Optional<Esame> getUltimoTentativo(Esame esame){
		// DA FARE
		Optional <Esame> optional = Optional.empty();
		List<Esame> tentativi = this.getTentativiPrecedenti(esame);
		if(tentativi.size()>0) {
			optional = Optional.of(tentativi.get(tentativi.size()-1));
		}
		return optional;
	}

	public Optional<Esame> getUltimoEsameDato(){
		// DA FARE
		Optional <Esame> optional = Optional.empty();
		if(this.listaEsami.size()>0) {
			optional = Optional.of(this.listaEsami.get(this.listaEsami.size()-1));
		}
		return optional;
	}

	
	public void inserisci(Esame esame) {
		// DA FARE
		if(esame == null) {
			throw new IllegalArgumentException ("esame null");
		}
		for(Esame test : this.listaEsami) {
			if(test.getAf().equals(esame.getAf()) && test.getVoto().superato()) {
				throw new IllegalArgumentException ("esame già superato");
			}
		}
		if(esame.getAf().getNome().toLowerCase().contains("prova finale")) {
			for(Esame test : this.listaEsami) {
				if(!(esame.getDate().isAfter(test.getDate()))){
					throw new IllegalArgumentException ("esame già superato");
				}
			}
		}
		for(Esame test : this.listaEsami) {
			if(test.getDate().equals(esame.getDate()) && test.getAf().equals(esame.getAf())) {
				throw new IllegalArgumentException ("stesso esame due volte in una data");
			}
		}
		this.listaEsami.add(esame);
		this.listaEsami.sort(this.cmp);
	}
	
	public double creditiAcquisiti() {
		// DA FARE
		double cfu = 0;
		for(Esame esame : this.listaEsami) {
			if(esame.getVoto().superato()) {
				cfu = cfu + esame.getAf().getCfu();
			}
		}
		return cfu;
	}
	
	public double mediaPesata() {
		// DA FARE
		double cfuDaVoto = 0;
		double numeratore = 0;
		for(Esame esame : this.listaEsami) {
			if(esame.getVoto().getValue().isPresent()) {
				cfuDaVoto = cfuDaVoto + esame.getAf().getCfu();
				numeratore = numeratore + esame.getVoto().getValue().getAsInt()*1.0*esame.getAf().getCfu();
			}
		}
		return numeratore / cfuDaVoto;
	}

	@Override
	public String toString() {
		return listaEsami.stream().map(Esame::toString).collect(Collectors.joining(System.lineSeparator()));
	}
	
}
