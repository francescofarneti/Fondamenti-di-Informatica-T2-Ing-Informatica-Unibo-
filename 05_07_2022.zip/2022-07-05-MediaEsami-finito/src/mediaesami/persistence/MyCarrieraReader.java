package mediaesami.persistence;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.Reader;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Locale;

import mediaesami.model.AttivitaFormativa;
import mediaesami.model.Carriera;
import mediaesami.model.Esame;
import mediaesami.model.Voto;


public class MyCarrieraReader implements CarrieraReader {

	/*
	 * 	27991	ANALISI MATEMATICA T-1				9,0		12/1/2020	RT
		27991	ANALISI MATEMATICA T-1				9,0		10/2/2020	22
		28004	FONDAMENTI DI INFORMATICA T-1		12,0	13/2/2020	24
		29228	GEOMETRIA E ALGEBRA T				6,0		18/1/2020	26
		26337	LINGUA INGLESE B-2					6,0
		27993	ANALISI MATEMATICA T-2				6,0		10/6/2020	RE
		27993	ANALISI MATEMATICA T-2				6,0		02/7/2020	RT
		28006	FONDAMENTI DI INFORMATICA T-2		12,0
		28011	RETI LOGICHE T						6,0
		...
	* */

	@Override
	public Carriera leggiCarriera(Reader rdr) throws IOException {
		// DA FARE
		Carriera carriera = new Carriera ();
		BufferedReader reader = new BufferedReader (rdr);
		String riga;
		while((riga = reader.readLine()) != null) {
			if(riga.isBlank()) {
				continue;
			}
			String [] items = riga.split("\\t+");
			Long id = Long.parseLong(items[0].trim());
			String nome = items[1].toUpperCase().trim();
			double cfu = Double.parseDouble(items[2].replace(",", ".").trim());
			
			
			if(items.length == 5) {
				DateTimeFormatter formatter = DateTimeFormatter.ofPattern("d/M/yyyy", Locale.ITALY);
				/**
				 * Nota: M va messo maiuscolo perchè in java m minuscolo indica i minuti
				 */
				LocalDate date;
				Voto voto;
				try {
					voto = Voto.of(items[4].trim());
				} catch (Exception e) {
					throw new BadFileFormatException ("errore nel parse voto" + riga +"--" +"--" + items[4].trim());
				}
				try {
					date = LocalDate.parse(items[3].trim(), formatter);
				} catch (Exception e) {
					throw new BadFileFormatException ("errore nel parse data" + riga +"--" + "--" + items[3].trim());
				}
				AttivitaFormativa af = new AttivitaFormativa(id,nome,cfu);
				Esame esame = new Esame (af,date,voto);
				carriera.inserisci(esame);
			}
			else {
				continue;
			}
		}
		return carriera;
	}
}