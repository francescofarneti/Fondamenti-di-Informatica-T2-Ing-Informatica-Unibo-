package contocorrente.persistence;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.Reader;
import java.text.NumberFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.FormatStyle;
import java.util.Locale;

import contocorrente.model.Movimento;
import contocorrente.model.ContoCorrente;
import contocorrente.model.Tipologia;


public class MyCCReader implements CCReader {

	/*  CC N.123456789
	 * 	31/01/22 31/01/22	10.317,81 	SALDO INIZIALE A VOSTRO CREDITO
		02/02/22 02/02/22	- 2,90 		IMP.BOLLO CC
		07/02/22 07/02/22 	- 61,59 	SPESE GESTIONE
		...
	 * */

	@Override
	public ContoCorrente readCC(Reader rdr) throws IOException {
		// *** DA FARE *** 
		// vedi testo per le specifiche
		BufferedReader reader = new BufferedReader (rdr);
		String identificativo = reader.readLine();
		if(!(identificativo.toLowerCase().contains("n.")) || identificativo.contains("-") || !(identificativo.toLowerCase().contains("cc"))) throw new BadFileFormatException("errore id");
		String [] idValido = identificativo.toLowerCase().split("n.");
		Long id;
		try {
			id = Long.parseLong(idValido[1].trim());
		} catch (Exception e) {
			throw new BadFileFormatException("errore id");
		}
		ContoCorrente cc = new ContoCorrente(id);
		String riga;
		while((riga = reader.readLine()) != null) {
			if(riga.isBlank()) continue;
			String [] items = riga.split("\\t+");
			if(items.length != 4) throw new BadFileFormatException ("lenght errati");
			DateTimeFormatter formatter = DateTimeFormatter.ofLocalizedDate(FormatStyle.SHORT).withLocale(Locale.ITALY);
			LocalDate dataContabile;
			LocalDate dataValuta;
			try {
				dataContabile = LocalDate.parse(items[0].trim(), formatter);
				dataValuta = LocalDate.parse(items[1].trim(), formatter);
			} catch(Exception e) {
				throw new BadFileFormatException("errore date");
			}
			NumberFormat formatter2 = NumberFormat.getNumberInstance(Locale.ITALY);
			double importo;
			try {
				importo = formatter2.parse(items[2].replace("\s", "").trim()).doubleValue();
			} catch(Exception e) {
				throw new BadFileFormatException("errore importo");
			}
			String causale = items[3].toUpperCase().trim();
			Tipologia tipologia;
			if(causale.toLowerCase().contains("saldo")) {
				tipologia = Tipologia.SALDO;
			}
			else if(importo>0) {
				tipologia = Tipologia.ACCREDITO;
			}
			else if(importo<0) {
				tipologia = Tipologia.ADDEBITO;
			}
			else {
				tipologia = Tipologia.NULLO;
			}
			
			Movimento movimento = new Movimento(dataContabile,dataValuta,tipologia,importo,causale);
			cc.aggiungi(movimento);
		}
		return cc;
	}
}