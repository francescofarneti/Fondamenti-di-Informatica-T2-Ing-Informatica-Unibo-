package cityparking.model;

import java.time.Duration;
import java.time.LocalDateTime;


public class MyCalcolatoreSosta extends CalcolatoreSosta {

	public MyCalcolatoreSosta(Tariffa tariffa) {
		super(tariffa);
	}

	// *** DA REALIZZARE ***
	@Override
	public Ricevuta calcola(LocalDateTime inizio, LocalDateTime fine) throws BadTimeIntervalException {
		if(inizio.isAfter(fine)) throw new BadTimeIntervalException();
		double costo=0;
		if(Duration.between(inizio, fine).toMinutes() <= 15) {
			costo = this.getTariffa().getCostoIniziale();
		}
		else if(Duration.between(inizio, fine).toMinutes()<=24*60) {
			double minuti = Duration.between(inizio, fine).toMinutes();
			int intervalli = (int) Math.ceil(minuti*1.0/15) - 1;
			costo = intervalli * this.getTariffa().getCostoUnitaSuccessive() + this.getTariffa().getCostoIniziale();
			if(costo>this.getTariffa().getCapGiornaliero()) {
				costo = this.getTariffa().getCapGiornaliero();
			}
		}
		else if(Duration.between(inizio, fine).toMinutes()>24*60) {
			double minuti = Duration.between(inizio, fine).toMinutes();
			int intervalli = (int) Math.ceil(minuti*1.0/(60*12))-2;
			costo = this.getTariffa().getCapGiornaliero() + intervalli * this.getTariffa().getOltre();
		}
		Ricevuta ricevuta = new Ricevuta (inizio,fine,costo);
		return ricevuta;
	}

}
