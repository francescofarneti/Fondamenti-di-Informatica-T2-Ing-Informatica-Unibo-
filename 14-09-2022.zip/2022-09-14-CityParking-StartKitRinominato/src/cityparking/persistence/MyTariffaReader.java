package cityparking.persistence;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.Reader;
import java.text.NumberFormat;
import java.time.Duration;
import java.util.Locale;

import cityparking.model.Tariffa;


public class MyTariffaReader implements TariffaReader {
	
	// *** DA REALIZZARE ***
	@Override
	public Tariffa leggiTariffa(Reader reader) throws IOException, BadFileFormatException {
		BufferedReader rdr = new BufferedReader (reader);
		
		String riga1 = rdr.readLine();
		if(riga1.contains("M") || riga1.contains("-") || !(riga1.toLowerCase().contains("m"))) throw new BadFileFormatException("");
		if(!(riga1.contains("Durata unità")))throw new BadFileFormatException("");
		String [] items1 = riga1.split("=");
		int minuti;
		try {
			minuti = Integer.parseInt(items1[1].toLowerCase().replace("m","").trim());
		} catch (Exception e) {
			throw new BadFileFormatException("errore parse minuti");
		}
		Duration intervallo = Duration.ofMinutes(minuti);
		
		double costoIniziale;
		NumberFormat formatter = NumberFormat.getCurrencyInstance(Locale.ITALY);
		String riga2 = rdr.readLine();
		if(!(riga2.contains("Costo iniziale")))throw new BadFileFormatException("");
		String [] items2 = riga2.split("=");
		try {
			costoIniziale = formatter.parse(items2[1].trim()).doubleValue();
		} catch (Exception e) {
			throw new BadFileFormatException("errore parse costo iniziale");
		}
		
		double unitaSuccessive;
		String riga3 = rdr.readLine();
		if(!(riga3.contains("Unità successive")))throw new BadFileFormatException("");
		String [] items3 = riga3.split("=");
		try {
			unitaSuccessive = formatter.parse(items3[1].trim()).doubleValue();
		} catch (Exception e) {
			throw new BadFileFormatException("errore parse unità successive");
		}
		
		double capGiornaliero;
		String riga4 = rdr.readLine();
		if(!(riga4.contains("Cap giornaliero")))throw new BadFileFormatException("");
		String [] items4 = riga4.split("=");
		try {
			capGiornaliero = formatter.parse(items4[1].trim()).doubleValue();
		} catch (Exception e) {
			throw new BadFileFormatException("errore parse cap giornaliero");
		}
		
		double oltre;
		String riga5 = rdr.readLine();
		if(!(riga5.contains("12h successive")))throw new BadFileFormatException("");
		String [] items5 = riga5.split("=");
		try {
			oltre = formatter.parse(items5[1].trim()).doubleValue();
		} catch (Exception e) {
			throw new BadFileFormatException("errore parse oltre");
		}
		
		Tariffa tariffa = new Tariffa(intervallo,costoIniziale,unitaSuccessive,capGiornaliero,oltre);
		return tariffa;
	}
		
}
