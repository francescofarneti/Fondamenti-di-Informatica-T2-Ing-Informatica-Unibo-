package cityparking.controller;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.time.format.FormatStyle;
import java.util.Locale;

import cityparking.model.MyCalcolatoreSosta;
import cityparking.model.Tariffa;
import cityparking.model.Ricevuta;
import cityparking.model.BadTimeIntervalException;
import cityparking.model.CalcolatoreSosta;


public class MyController implements Controller {

	@SuppressWarnings("unused")
	private CalcolatoreSosta calc;

	public MyController(Tariffa tariffa) {
		calc = new MyCalcolatoreSosta(tariffa);
	}

	
	// *** DA REALIZZARE ***
	@Override
	public Ricevuta calcolaSosta(LocalDate dataInizio, String strOraInizio, LocalDate dataFine, String strOraFine) 
			throws BadTimeIntervalException, BadTimeFormatException {
		DateTimeFormatter formatter = DateTimeFormatter.ofLocalizedTime(FormatStyle.SHORT).withLocale(Locale.ITALY);
		LocalTime oraInizio = LocalTime.parse(strOraInizio, formatter);
		LocalTime oraFine = LocalTime.parse(strOraFine, formatter);
		LocalDateTime inizio = LocalDateTime.of(dataInizio, oraInizio);
		LocalDateTime fine = LocalDateTime.of(dataFine, oraFine);
		Ricevuta ricevuta = calc.calcola(inizio, fine);
		return ricevuta;
	}
	
}
